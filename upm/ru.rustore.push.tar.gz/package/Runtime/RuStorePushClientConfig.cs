using UnityEngine;

namespace RuStore.PushClient {

    public class RuStorePushClientConfig {

        public IMessagingServiceListener messagingServiceListener;
        public ILogListener logListener;
    }
}
