﻿using System.Collections.Generic;

namespace RuStore.PushClient {

    public class TestNotificationPayload  {

        public string title;
        public string body;
        public string imgUrl;
        public Dictionary<string, string> data;
    }
}