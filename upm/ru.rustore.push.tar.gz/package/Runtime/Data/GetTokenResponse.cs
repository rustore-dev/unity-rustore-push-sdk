using System.Collections.Generic;

namespace RuStore.PushClient {

    public class GetTokenResponse {
           public string token;
    }
}
