namespace RuStore.PushClient
{
    public enum ClickActionType
    {
        DEFAULT,
        DEEP_LINK,
    }
}
