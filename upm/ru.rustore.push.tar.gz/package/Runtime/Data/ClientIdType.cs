﻿
namespace RuStore.PushClient {

    public enum ClientIdType {
        GAID,
        OAID,
    }
}