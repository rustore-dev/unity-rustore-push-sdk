using System.Collections.Generic;

namespace RuStore.PushClient {

    public class DeleteTokenResponse {
    }
}
